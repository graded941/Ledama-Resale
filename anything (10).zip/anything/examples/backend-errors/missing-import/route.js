const a = foo.bar;

export function GET(request) {
  return request;
}

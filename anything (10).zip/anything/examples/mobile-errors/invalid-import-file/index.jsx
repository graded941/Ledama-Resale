import foo from './foo';
export default function Page() {
  return <div>{foo}</div>;
}

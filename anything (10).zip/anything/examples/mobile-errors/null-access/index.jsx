export default function Bug() {
  const obj = null;
  return <p>{obj.key}</p>;
}

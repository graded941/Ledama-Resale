import foo from './missing';

export default function Page() {
  return foo;
}

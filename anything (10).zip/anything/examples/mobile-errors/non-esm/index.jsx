module.exports = function () {
  return <div>CommonJS default export</div>;
};

export default function Index() {
	return <div>hello ticket</div>;
}

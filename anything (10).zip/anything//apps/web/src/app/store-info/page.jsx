import Header from "@/components/Header";
import {
  MapPin,
  Clock,
  Phone,
  CreditCard,
  MessageCircle,
  Heart,
} from "lucide-react";

export default function StoreInfoPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-green-700 via-green-600 to-green-800 text-white rounded-2xl p-8 md:p-12 mb-8 shadow-xl">
          <h1 className="text-4xl md:text-6xl font-bungee mb-4 tracking-wider text-center drop-shadow-lg">
            <span className="text-yellow-300">KABARAK</span>
            <span className="text-white"> Market</span>
          </h1>
          <p className="text-xl md:text-2xl text-center font-bold text-yellow-300 mb-2">
            Quality Resale, Unbeatable Prices! 🛍️
          </p>
          <p className="text-center text-green-100 text-lg">
            Your trusted marketplace at Kabarak University
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Contact */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-green-100 p-3 rounded-full">
                <Phone className="text-green-700" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-gray-800">Contact Us</h2>
            </div>
            <p className="text-lg text-gray-700 mb-4 font-medium">
              <a
                href="tel:+254705769770"
                className="hover:text-green-600 transition-colors"
              >
                +254 705 769 770
              </a>
            </p>
            <a
              href="https://wa.me/254705769770"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-semibold transition-colors"
            >
              <MessageCircle size={20} />
              WhatsApp Us
            </a>
          </div>

          {/* Location */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-green-100 p-3 rounded-full">
                <MapPin className="text-green-700" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-gray-800">Visit Us</h2>
            </div>
            <p className="text-lg text-gray-700 mb-4 font-medium">
              Chapchap Rafiki
              <br />
              Kabarak University
              <br />
              Kenya
            </p>
            <a
              href="https://maps.app.goo.gl/nzDqiEba9K4JHNA47"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-semibold transition-colors"
            >
              <MapPin size={20} />
              Get Directions
            </a>
          </div>

          {/* Opening Hours */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <Clock className="text-blue-700" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-gray-800">Hours</h2>
            </div>
            <div className="space-y-2 text-gray-600">
              <div className="flex justify-between">
                <span className="font-medium">Monday - Saturday</span>
                <span>9:00 AM - 7:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Sunday</span>
                <span className="text-red-600 font-semibold">Closed</span>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-orange-100 p-3 rounded-full">
                <CreditCard className="text-orange-700" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-gray-800">Payment</h2>
            </div>
            <p className="text-gray-600 mb-4">We accept:</p>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                M-Pesa
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                Cash
              </li>
            </ul>
          </div>
        </div>

        {/* Map */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            Find Us Here
          </h2>
          <div className="w-full h-96 rounded-lg overflow-hidden shadow-md">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.762!2d35.9!3d-0.3!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMMKwMTgnMDAuMCJTIDM1wrA1NCcwMC4wIkU!5e0!3m2!1sen!2ske!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="KABARAK Market Location"
            ></iframe>
          </div>
        </div>

        {/* About Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-green-100 p-3 rounded-full">
              <Heart className="text-green-700" size={24} />
            </div>
            <h2 className="text-2xl font-bold text-gray-800">
              About KABARAK Market
            </h2>
          </div>
          <div className="prose prose-lg max-w-none text-gray-700 space-y-4">
            <p>
              Welcome to{" "}
              <span className="font-bold text-green-700">KABARAK Market</span> -
              your premier destination for quality resale items at Kabarak
              University! We serve the student community and beyond with amazing
              deals on everyday essentials.
            </p>
            <p>
              Whether you're looking for stylish clothing, comfortable shoes,
              the latest electronics, or unique finds, we've got you covered.
              Every item is carefully selected and priced to give you the best
              value for your money.
            </p>
            <p className="font-semibold text-green-700">
              Visit us at Chapchap Rafiki or call +254 705 769 770 to learn
              more!
            </p>
          </div>
        </div>

        {/* How It Works */}
        <div className="bg-gradient-to-r from-green-700 to-green-900 text-white rounded-lg shadow-lg p-8">
          <h2 className="text-3xl font-bold mb-6 text-center">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                1
              </div>
              <h3 className="font-semibold text-lg mb-2">Browse Online</h3>
              <p className="text-green-100">
                Search our catalog and find items you like
              </p>
            </div>
            <div className="text-center">
              <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                2
              </div>
              <h3 className="font-semibold text-lg mb-2">Contact Us</h3>
              <p className="text-green-100">
                Message us on WhatsApp to confirm availability
              </p>
            </div>
            <div className="text-center">
              <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                3
              </div>
              <h3 className="font-semibold text-lg mb-2">Visit & Purchase</h3>
              <p className="text-green-100">
                Come to our store to see the item and complete your purchase
              </p>
            </div>
          </div>
        </div>

        <div className="text-center mt-8">
          <a
            href="/"
            className="text-green-700 hover:text-green-800 font-semibold text-lg"
          >
            ← Back to Browse Items
          </a>
        </div>
      </div>
    </div>
  );
}

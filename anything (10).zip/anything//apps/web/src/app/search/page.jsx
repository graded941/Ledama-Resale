"use client";

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import SearchBar from "@/components/SearchBar";
import ItemCard from "@/components/ItemCard";
import { Filter } from "lucide-react";

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("newest");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const query = params.get("q") || "";
      setSearchQuery(query);
    }
  }, []);

  const { data, isLoading } = useQuery({
    queryKey: ["search", searchQuery, sortBy],
    queryFn: async () => {
      let url = `/api/items?sortBy=${sortBy}`;
      if (searchQuery) {
        url += `&search=${encodeURIComponent(searchQuery)}`;
      }
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Failed to fetch items");
      }
      return response.json();
    },
    enabled: true,
  });

  const items = data?.items || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Search Bar */}
        <div className="mb-8">
          <SearchBar initialValue={searchQuery} />
        </div>

        {/* Results Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            {searchQuery ? `Search Results for "${searchQuery}"` : "All Items"}
          </h1>
          <p className="text-gray-600">
            {items.length} {items.length === 1 ? "item" : "items"} found
          </p>
        </div>

        {/* Sort Filter */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Filter size={20} className="text-gray-600" />
            <h2 className="font-semibold text-gray-800">Sort By</h2>
          </div>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="w-full md:w-64 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          >
            <option value="newest">Newest First</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
          </select>
        </div>

        {/* Results Grid */}
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-gray-500">Searching...</p>
          </div>
        ) : items.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {items.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow-md">
            <p className="text-gray-500 text-lg mb-4">
              {searchQuery
                ? `No items found matching "${searchQuery}"`
                : "No items available yet"}
            </p>
            <p className="text-gray-400 mb-6">
              Try searching for something else or browse our categories
            </p>
            <a
              href="/"
              className="text-green-700 hover:text-green-800 font-semibold"
            >
              ← Back to Home
            </a>
          </div>
        )}
      </div>
    </div>
  );
}

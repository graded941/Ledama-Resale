"use client";

import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import SearchBar from "@/components/SearchBar";
import CategoryGrid from "@/components/CategoryGrid";
import ItemCard from "@/components/ItemCard";
import { MapPin, Clock, Phone } from "lucide-react";

export default function HomePage() {
  const [error, setError] = useState(null);

  const { data: categoriesData } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) {
        throw new Error("Failed to fetch categories");
      }
      return response.json();
    },
  });

  const { data: itemsData } = useQuery({
    queryKey: ["featured-items"],
    queryFn: async () => {
      const response = await fetch("/api/items?sortBy=newest");
      if (!response.ok) {
        throw new Error("Failed to fetch items");
      }
      return response.json();
    },
  });

  const categories = categoriesData?.categories || [];
  const featuredItems = itemsData?.items?.slice(0, 6) || [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-700 to-green-900 text-white py-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-5xl md:text-7xl font-bungee mb-4 tracking-wider">
            <span className="text-yellow-300 drop-shadow-lg">KABARAK</span>
            <span className="text-white drop-shadow-lg"> Market</span>
          </h2>
          <p className="text-2xl md:text-3xl font-bold text-yellow-300 mb-3">
            Quality Resale, Unbeatable Prices! 🛍️
          </p>
          <p className="text-xl mb-8 text-green-100">
            Your trusted marketplace at Kabarak University
          </p>
          <div className="mb-8">
            <SearchBar />
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <a
              href="tel:+254705769770"
              className="bg-yellow-400 hover:bg-yellow-500 text-green-900 font-bold py-3 px-6 rounded-full transition-all transform hover:scale-105 shadow-lg flex items-center gap-2"
            >
              <Phone size={20} />
              Call: +254 705 769 770
            </a>
            <a
              href="https://maps.app.goo.gl/nzDqiEba9K4JHNA47"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white hover:bg-green-50 text-green-800 font-bold py-3 px-6 rounded-full transition-all transform hover:scale-105 shadow-lg flex items-center gap-2"
            >
              <MapPin size={20} />
              Visit Us
            </a>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold mb-6 text-gray-800">
          Shop by Category
        </h2>
        <CategoryGrid categories={categories} />
      </section>

      {/* Featured Items */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-bold text-gray-800">Recently Added</h2>
          <a
            href="/search"
            className="text-green-700 hover:text-green-800 font-semibold"
          >
            View All →
          </a>
        </div>

        {featuredItems.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredItems.map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-12">
            No items available yet. Check back soon!
          </p>
        )}
      </section>

      {/* Store Info Snapshot */}
      <section className="bg-green-100 py-12 px-4 mt-12">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6 text-gray-800">
            Visit Our Store
          </h2>
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <div className="bg-white rounded-lg p-6 shadow-md">
              <MapPin className="mx-auto mb-3 text-green-700" size={32} />
              <h3 className="font-semibold text-lg mb-2">Location</h3>
              <p className="text-gray-600">Chapchap Rafiki</p>
              <p className="text-gray-600">Kabarak University, Kenya</p>
              <a
                href="https://maps.app.goo.gl/nzDqiEba9K4JHNA47"
                target="_blank"
                rel="noopener noreferrer"
                className="text-green-700 hover:text-green-800 font-semibold mt-2 inline-block"
              >
                Get Directions →
              </a>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-md">
              <Phone className="mx-auto mb-3 text-green-700" size={32} />
              <h3 className="font-semibold text-lg mb-2">Contact Us</h3>
              <p className="text-gray-600 font-medium">+254 705 769 770</p>
              <a
                href="https://wa.me/254705769770"
                target="_blank"
                rel="noopener noreferrer"
                className="text-green-700 hover:text-green-800 font-semibold mt-2 inline-block"
              >
                WhatsApp Us →
              </a>
            </div>
          </div>
          <a
            href="/store-info"
            className="inline-block bg-green-700 hover:bg-green-800 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
          >
            More Store Info
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 px-4 mt-12">
        <div className="max-w-7xl mx-auto text-center">
          <h3 className="text-2xl font-bungee mb-2">
            <span className="text-yellow-300">KABARAK</span>
            <span className="text-white"> Market</span>
          </h3>
          <p className="mb-2">
            © {new Date().getFullYear()} KABARAK Market. All rights reserved.
          </p>
          <p className="text-gray-400">Quality Resale, Unbeatable Prices</p>
          <p className="text-gray-400 mt-2">
            Chapchap Rafiki, Kabarak University
          </p>
        </div>
      </footer>
    </div>
  );
}

"use client";

import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import useUpload from "@/utils/useUpload";
import { Upload, X, Tag, Save, Check, Eye, EyeOff } from "lucide-react";

export default function AdminPage() {
  const queryClient = useQueryClient();
  const [upload, { loading: uploading }] = useUpload();

  // Form state
  const [formData, setFormData] = useState({
    unique_id: "",
    name: "",
    price: "",
    condition: "",
    description: "",
    category_id: "",
  });
  const [photos, setPhotos] = useState([]);
  const [uploadingPhotos, setUploadingPhotos] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // Fetch categories
  const { data: categoriesData } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const response = await fetch("/api/categories");
      if (!response.ok) throw new Error("Failed to fetch categories");
      return response.json();
    },
  });

  // Fetch recent items
  const { data: itemsData, refetch: refetchItems } = useQuery({
    queryKey: ["admin-items"],
    queryFn: async () => {
      const response = await fetch("/api/items?sortBy=newest");
      if (!response.ok) throw new Error("Failed to fetch items");
      return response.json();
    },
  });

  const categories = categoriesData?.categories || [];
  const recentItems = itemsData?.items?.slice(0, 10) || [];

  // Generate unique ID
  const generateUniqueId = () => {
    const count = (itemsData?.items?.length || 0) + 1;
    const id = `KBK-${String(count).padStart(4, "0")}`;
    setFormData({ ...formData, unique_id: id });
  };

  // Handle photo upload
  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploadingPhotos(true);
    setErrorMessage("");

    try {
      const uploadedUrls = [];
      for (const file of files) {
        const { url, error } = await upload({ file });
        if (error) {
          setErrorMessage(`Failed to upload ${file.name}: ${error}`);
          continue;
        }
        if (url) {
          uploadedUrls.push(url);
        }
      }
      setPhotos([...photos, ...uploadedUrls]);
      setSuccessMessage(
        `Successfully uploaded ${uploadedUrls.length} photo(s)`,
      );
      setTimeout(() => setSuccessMessage(""), 3000);
    } catch (error) {
      console.error("Upload error:", error);
      setErrorMessage("Failed to upload photos");
    } finally {
      setUploadingPhotos(false);
    }
  };

  // Remove photo
  const removePhoto = (index) => {
    setPhotos(photos.filter((_, i) => i !== index));
  };

  // Create item mutation
  const createItemMutation = useMutation({
    mutationFn: async (itemData) => {
      const response = await fetch("/api/items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(itemData),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to create item");
      }
      return response.json();
    },
    onSuccess: () => {
      setSuccessMessage("Item added successfully! 🎉");
      setFormData({
        unique_id: "",
        name: "",
        price: "",
        condition: "",
        description: "",
        category_id: "",
      });
      setPhotos([]);
      queryClient.invalidateQueries(["admin-items"]);
      refetchItems();
      setTimeout(() => setSuccessMessage(""), 5000);
    },
    onError: (error) => {
      setErrorMessage(error.message);
    },
  });

  // Mark as sold mutation
  const markAsSoldMutation = useMutation({
    mutationFn: async (uniqueId) => {
      const response = await fetch(`/api/items/${uniqueId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "sold" }),
      });
      if (!response.ok) throw new Error("Failed to mark as sold");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-items"]);
      refetchItems();
      setSuccessMessage("Item marked as sold! ✅");
      setTimeout(() => setSuccessMessage(""), 3000);
    },
  });

  // Mark as available mutation
  const markAsAvailableMutation = useMutation({
    mutationFn: async (uniqueId) => {
      const response = await fetch(`/api/items/${uniqueId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "available" }),
      });
      if (!response.ok) throw new Error("Failed to mark as available");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["admin-items"]);
      refetchItems();
      setSuccessMessage("Item marked as available! ✅");
      setTimeout(() => setSuccessMessage(""), 3000);
    },
  });

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorMessage("");

    if (
      !formData.unique_id ||
      !formData.name ||
      !formData.price ||
      !formData.category_id
    ) {
      setErrorMessage("Please fill in all required fields");
      return;
    }

    if (photos.length === 0) {
      setErrorMessage("Please upload at least one photo");
      return;
    }

    createItemMutation.mutate({
      ...formData,
      price: parseFloat(formData.price),
      category_id: parseInt(formData.category_id),
      photos,
    });
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-green-800 text-white py-4 px-6 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bungee tracking-wider">
              <span className="text-yellow-300">KABARAK</span>
              <span className="text-white"> Market</span>
            </h1>
            <p className="text-green-200 text-sm">
              Staff Admin - Manage Your Inventory
            </p>
          </div>
          <a
            href="/"
            className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg transition-colors"
          >
            View Customer Site →
          </a>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Success/Error Messages */}
        {successMessage && (
          <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-6 flex items-center gap-2">
            <Check size={20} />
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-6">
            {errorMessage}
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Add Item Form */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
              <Tag size={24} className="text-green-700" />
              Add New Item
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Unique ID */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Unique ID <span className="text-red-500">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={formData.unique_id}
                    onChange={(e) =>
                      setFormData({ ...formData, unique_id: e.target.value })
                    }
                    placeholder="KBK-0001"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  />
                  <button
                    type="button"
                    onClick={generateUniqueId}
                    className="bg-gray-200 hover:bg-gray-300 px-4 py-2 rounded-lg transition-colors text-sm font-medium"
                  >
                    Auto-generate
                  </button>
                </div>
              </div>

              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Item Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="Men's Nike Air Max"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.category_id}
                  onChange={(e) =>
                    setFormData({ ...formData, category_id: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                >
                  <option value="">Select a category</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.icon} {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Price */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Price (KES) <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) =>
                    setFormData({ ...formData, price: e.target.value })
                  }
                  placeholder="3500"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                />
              </div>

              {/* Condition */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Condition
                </label>
                <select
                  value={formData.condition}
                  onChange={(e) =>
                    setFormData({ ...formData, condition: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="">Select condition</option>
                  <option value="New">New</option>
                  <option value="Like new">Like New</option>
                  <option value="Good">Good</option>
                  <option value="Gently used">Gently Used</option>
                  <option value="Fair">Fair</option>
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  placeholder="Add details about size, color, condition, etc."
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              {/* Photos */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Photos <span className="text-red-500">*</span>
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-green-500 transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handlePhotoUpload}
                    className="hidden"
                    id="photo-upload"
                    disabled={uploadingPhotos}
                  />
                  <label
                    htmlFor="photo-upload"
                    className="cursor-pointer flex flex-col items-center"
                  >
                    <Upload className="text-gray-400 mb-2" size={32} />
                    <p className="text-gray-600 font-medium">
                      {uploadingPhotos
                        ? "Uploading..."
                        : "Click to upload photos"}
                    </p>
                    <p className="text-gray-400 text-sm">or drag and drop</p>
                  </label>
                </div>

                {photos.length > 0 && (
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    {photos.map((photo, index) => (
                      <div key={index} className="relative aspect-square">
                        <img
                          src={photo}
                          alt={`Upload ${index + 1}`}
                          className="w-full h-full object-cover rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={() => removePhoto(index)}
                          className="absolute top-1 right-1 bg-red-500 hover:bg-red-600 text-white p-1 rounded-full"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={createItemMutation.isPending || uploadingPhotos}
                className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Save size={20} />
                {createItemMutation.isPending
                  ? "Adding Item..."
                  : "Add Item to Catalog"}
              </button>
            </form>
          </div>

          {/* Recent Items List */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">
              Recent Items
            </h2>

            {recentItems.length === 0 ? (
              <p className="text-gray-500 text-center py-8">
                No items yet. Add your first item!
              </p>
            ) : (
              <div className="space-y-3 max-h-[600px] overflow-y-auto">
                {recentItems.map((item) => (
                  <div
                    key={item.id}
                    className={`border rounded-lg p-4 ${
                      item.status === "sold"
                        ? "bg-gray-50 border-gray-300"
                        : "border-gray-200"
                    }`}
                  >
                    <div className="flex gap-3">
                      <img
                        src={
                          item.photos?.[0] ||
                          "https://ucarecdn.com/placeholder.jpg"
                        }
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-gray-800 truncate">
                              {item.name}
                            </h3>
                            <p className="text-sm text-gray-500 font-mono">
                              {item.unique_id}
                            </p>
                          </div>
                          <p className="font-bold text-green-700 whitespace-nowrap">
                            KES {parseFloat(item.price).toLocaleString()}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 mt-2">
                          {item.status === "sold" ? (
                            <>
                              <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full font-medium">
                                SOLD
                              </span>
                              <button
                                onClick={() =>
                                  markAsAvailableMutation.mutate(item.unique_id)
                                }
                                className="text-xs bg-green-100 hover:bg-green-200 text-green-800 px-3 py-1 rounded-full transition-colors flex items-center gap-1"
                              >
                                <Eye size={12} />
                                Mark Available
                              </button>
                            </>
                          ) : (
                            <>
                              <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-medium">
                                AVAILABLE
                              </span>
                              <button
                                onClick={() =>
                                  markAsSoldMutation.mutate(item.unique_id)
                                }
                                className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-1 rounded-full transition-colors flex items-center gap-1"
                              >
                                <EyeOff size={12} />
                                Mark Sold
                              </button>
                            </>
                          )}
                          <a
                            href={`/items/${item.unique_id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:text-blue-800"
                          >
                            View →
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

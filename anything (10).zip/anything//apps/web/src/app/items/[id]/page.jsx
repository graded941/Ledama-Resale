"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import { Tag, MessageCircle, ChevronLeft, ChevronRight } from "lucide-react";

export default function ItemDetailPage({ params }) {
  const { id } = params;
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);

  const { data, isLoading } = useQuery({
    queryKey: ["item", id],
    queryFn: async () => {
      const response = await fetch(`/api/items/${id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch item");
      }
      return response.json();
    },
  });

  const item = data?.item;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-12 text-center">
          <p className="text-gray-500">Loading item details...</p>
        </div>
      </div>
    );
  }

  if (!item) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">
            Item Not Found
          </h1>
          <a
            href="/"
            className="text-green-700 hover:text-green-800 font-semibold"
          >
            ← Back to Home
          </a>
        </div>
      </div>
    );
  }

  const photos =
    item.photos && item.photos.length > 0
      ? item.photos
      : ["https://ucarecdn.com/placeholder.jpg"];

  const whatsappMessage = `Hi, I'm interested in item ${item.unique_id} (${item.name}). Is it still available? I'll come by to see it.`;
  const whatsappUrl = `https://wa.me/254700000000?text=${encodeURIComponent(whatsappMessage)}`;

  const nextPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev + 1) % photos.length);
  };

  const prevPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev - 1 + photos.length) % photos.length);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 py-8">
        <a
          href="/"
          className="text-green-700 hover:text-green-800 font-semibold mb-6 inline-block"
        >
          ← Back to Browse
        </a>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Photo Gallery */}
          <div>
            <div className="relative bg-white rounded-lg shadow-lg overflow-hidden aspect-square">
              <img
                src={photos[currentPhotoIndex]}
                alt={`${item.name} - Photo ${currentPhotoIndex + 1}`}
                className="w-full h-full object-cover"
              />

              {photos.length > 1 && (
                <>
                  <button
                    onClick={prevPhoto}
                    className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full shadow-lg transition-colors"
                  >
                    <ChevronLeft size={24} />
                  </button>
                  <button
                    onClick={nextPhoto}
                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white p-2 rounded-full shadow-lg transition-colors"
                  >
                    <ChevronRight size={24} />
                  </button>

                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
                    {currentPhotoIndex + 1} / {photos.length}
                  </div>
                </>
              )}
            </div>

            {/* Thumbnail Strip */}
            {photos.length > 1 && (
              <div className="flex gap-2 mt-4 overflow-x-auto">
                {photos.map((photo, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentPhotoIndex(index)}
                    className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                      index === currentPhotoIndex
                        ? "border-green-700 scale-105"
                        : "border-gray-200 hover:border-green-400"
                    }`}
                  >
                    <img
                      src={photo}
                      alt={`Thumbnail ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Item Details */}
          <div>
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center gap-2 text-gray-500 mb-2">
                <Tag size={16} />
                <span className="text-sm font-mono">{item.unique_id}</span>
              </div>

              <h1 className="text-3xl font-bold text-gray-800 mb-4">
                {item.name}
              </h1>

              <div className="flex items-center gap-4 mb-6">
                <p className="text-4xl font-bold text-green-700">
                  KES {parseFloat(item.price).toLocaleString()}
                </p>
                {item.condition && (
                  <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                    {item.condition}
                  </span>
                )}
              </div>

              {item.category_name && (
                <div className="mb-6">
                  <p className="text-sm text-gray-500 mb-1">Category</p>
                  <a
                    href={`/categories/${item.category_slug}`}
                    className="text-green-700 hover:text-green-800 font-semibold"
                  >
                    {item.category_name}
                  </a>
                </div>
              )}

              {item.description && (
                <div className="mb-6">
                  <h2 className="font-semibold text-gray-800 mb-2">
                    Description
                  </h2>
                  <p className="text-gray-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              )}

              {/* WhatsApp Button */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 px-6 rounded-lg transition-colors shadow-lg hover:shadow-xl"
              >
                <MessageCircle size={24} />
                I'm Interested - Contact on WhatsApp
              </a>

              <p className="text-sm text-gray-500 text-center mt-4">
                This will open WhatsApp with a pre-filled message about this
                item
              </p>
            </div>

            {/* Store Visit Info */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
              <h3 className="font-semibold text-blue-900 mb-2">
                📍 Visit Our Store
              </h3>
              <p className="text-blue-800 text-sm mb-2">
                All purchases are completed in-store. Payment via M-Pesa.
              </p>
              <a
                href="/store-info"
                className="text-blue-700 hover:text-blue-800 font-semibold text-sm"
              >
                View store location & hours →
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

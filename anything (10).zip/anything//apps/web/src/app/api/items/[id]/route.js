import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { id } = params;

    const result = await sql`
      SELECT 
        i.id, 
        i.unique_id, 
        i.name, 
        i.price, 
        i.condition, 
        i.description, 
        i.photos, 
        i.status,
        i.created_at,
        c.name as category_name,
        c.slug as category_slug
      FROM items i
      LEFT JOIN categories c ON i.category_id = c.id
      WHERE i.unique_id = ${id}
    `;

    if (result.length === 0) {
      return Response.json({ error: "Item not found" }, { status: 404 });
    }

    return Response.json({ item: result[0] });
  } catch (error) {
    console.error("Error fetching item:", error);
    return Response.json({ error: "Failed to fetch item" }, { status: 500 });
  }
}

export async function PATCH(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();

    const setClauses = [];
    const values = [];
    let paramCount = 0;

    if (body.name !== undefined) {
      paramCount++;
      setClauses.push(`name = $${paramCount}`);
      values.push(body.name);
    }
    if (body.price !== undefined) {
      paramCount++;
      setClauses.push(`price = $${paramCount}`);
      values.push(body.price);
    }
    if (body.condition !== undefined) {
      paramCount++;
      setClauses.push(`condition = $${paramCount}`);
      values.push(body.condition);
    }
    if (body.description !== undefined) {
      paramCount++;
      setClauses.push(`description = $${paramCount}`);
      values.push(body.description);
    }
    if (body.category_id !== undefined) {
      paramCount++;
      setClauses.push(`category_id = $${paramCount}`);
      values.push(body.category_id);
    }
    if (body.photos !== undefined) {
      paramCount++;
      setClauses.push(`photos = $${paramCount}`);
      values.push(body.photos);
    }
    if (body.status !== undefined) {
      paramCount++;
      setClauses.push(`status = $${paramCount}`);
      values.push(body.status);
    }

    if (setClauses.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    paramCount++;
    values.push(id);

    const queryText = `
      UPDATE items
      SET ${setClauses.join(", ")}
      WHERE unique_id = $${paramCount}
      RETURNING *
    `;

    const result = await sql(queryText, values);

    if (result.length === 0) {
      return Response.json({ error: "Item not found" }, { status: 404 });
    }

    return Response.json({ item: result[0] });
  } catch (error) {
    console.error("Error updating item:", error);
    return Response.json({ error: "Failed to update item" }, { status: 500 });
  }
}

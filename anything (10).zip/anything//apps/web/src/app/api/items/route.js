import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const search = searchParams.get("search");
    const sortBy = searchParams.get("sortBy") || "newest";
    const condition = searchParams.get("condition");

    let queryText = `
      SELECT 
        i.id, 
        i.unique_id, 
        i.name, 
        i.price, 
        i.condition, 
        i.description, 
        i.photos, 
        i.created_at,
        c.name as category_name,
        c.slug as category_slug
      FROM items i
      LEFT JOIN categories c ON i.category_id = c.id
      WHERE i.status = 'available'
    `;

    const values = [];
    let paramCount = 0;

    if (category) {
      paramCount++;
      queryText += ` AND c.slug = $${paramCount}`;
      values.push(category);
    }

    if (search) {
      paramCount++;
      queryText += ` AND (LOWER(i.name) LIKE LOWER($${paramCount}) OR LOWER(i.description) LIKE LOWER($${paramCount}))`;
      values.push(`%${search}%`);
    }

    if (condition) {
      paramCount++;
      queryText += ` AND LOWER(i.condition) = LOWER($${paramCount})`;
      values.push(condition);
    }

    // Add sorting
    if (sortBy === "price-low") {
      queryText += " ORDER BY i.price ASC";
    } else if (sortBy === "price-high") {
      queryText += " ORDER BY i.price DESC";
    } else {
      queryText += " ORDER BY i.created_at DESC";
    }

    const items = await sql(queryText, values);

    return Response.json({ items });
  } catch (error) {
    console.error("Error fetching items:", error);
    return Response.json({ error: "Failed to fetch items" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      unique_id,
      name,
      price,
      condition,
      description,
      category_id,
      photos,
    } = body;

    if (!unique_id || !name || !price || !category_id) {
      return Response.json(
        {
          error: "Missing required fields: unique_id, name, price, category_id",
        },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO items (unique_id, name, price, condition, description, category_id, photos)
      VALUES (${unique_id}, ${name}, ${price}, ${condition || null}, ${description || null}, ${category_id}, ${photos || []})
      RETURNING *
    `;

    return Response.json({ item: result[0] }, { status: 201 });
  } catch (error) {
    console.error("Error creating item:", error);
    return Response.json({ error: "Failed to create item" }, { status: 500 });
  }
}

import { Store, Menu, Phone, MapPin } from "lucide-react";

export default function Header() {
  return (
    <>
      {/* Top contact bar */}
      <div className="bg-green-900 text-white py-2 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-center md:justify-between gap-3 text-sm">
          <a
            href="tel:+254705769770"
            className="flex items-center gap-2 hover:text-yellow-300 transition-colors"
          >
            <Phone size={16} />
            <span>+254 705 769 770</span>
          </a>
          <a
            href="https://maps.app.goo.gl/nzDqiEba9K4JHNA47"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 hover:text-yellow-300 transition-colors"
          >
            <MapPin size={16} />
            <span>Chapchap Rafiki, Kabarak University</span>
          </a>
        </div>
      </div>

      {/* Main header */}
      <header className="bg-[#1a472a] text-white sticky top-0 z-50 shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <a
              href="/"
              className="flex flex-col hover:opacity-90 transition-opacity"
            >
              <h1 className="text-3xl md:text-4xl font-bungee tracking-wider">
                <span className="text-yellow-300">KABARAK</span>
                <span className="text-white"> Market</span>
              </h1>
              <p className="text-green-200 text-xs mt-1">
                Quality Resale, Unbeatable Prices
              </p>
            </a>

            <nav className="hidden md:flex items-center gap-6">
              <a href="/" className="hover:text-yellow-300 transition-colors">
                Home
              </a>
              <a
                href="/store-info"
                className="hover:text-yellow-300 transition-colors"
              >
                Store Info
              </a>
              <a
                href="https://wa.me/254705769770"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-500 hover:bg-green-600 px-4 py-2 rounded-lg transition-colors"
              >
                WhatsApp Us
              </a>
            </nav>

            <button className="md:hidden">
              <Menu size={24} />
            </button>
          </div>
        </div>
      </header>
    </>
  );
}

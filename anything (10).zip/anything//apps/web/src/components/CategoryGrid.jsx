export default function CategoryGrid({ categories }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {categories.map((category) => (
        <a
          key={category.id}
          href={`/categories/${category.slug}`}
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl hover:scale-105 transition-all duration-300 text-center group"
        >
          <div className="text-4xl mb-2">{category.icon}</div>
          <h3 className="font-semibold text-gray-800 group-hover:text-green-700 transition-colors">
            {category.name}
          </h3>
        </a>
      ))}
    </div>
  );
}

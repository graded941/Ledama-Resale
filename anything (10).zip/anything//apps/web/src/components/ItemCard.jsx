import { Tag } from "lucide-react";

export default function ItemCard({ item }) {
  const firstPhoto =
    item.photos && item.photos.length > 0
      ? item.photos[0]
      : "https://ucarecdn.com/placeholder.jpg";

  return (
    <a
      href={`/items/${item.unique_id}`}
      className="group bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300"
    >
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img
          src={firstPhoto}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {item.condition && (
          <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-md text-xs font-medium">
            {item.condition}
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-lg mb-1 line-clamp-2 group-hover:text-green-700 transition-colors">
          {item.name}
        </h3>

        <div className="flex items-center gap-1 text-gray-500 text-sm mb-2">
          <Tag size={14} />
          <span>{item.unique_id}</span>
        </div>

        <div className="flex items-center justify-between">
          <p className="text-2xl font-bold text-green-700">
            KES {parseFloat(item.price).toLocaleString()}
          </p>
          {item.category_name && (
            <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
              {item.category_name}
            </span>
          )}
        </div>
      </div>
    </a>
  );
}
